function relocate()
{
    var un = document.login.user.value;
    var pw = document.login.pass.value;
    if((un == "admin") && (pw == "admin"))
    {
     location.href = "aindex.jsp";
     return false;
    }
    else if((un == "nurse") && (pw == "nurse"))
        {
         location.href = "nindex.jsp";
         return false;
        }
        else if((un == "doctor") && (pw == "doctor"))
        {
         location.href = "dindex.jsp";
         return false;
        }   
    else {
        alert ("Login was unsuccessful, please check your username and password");
    }
  }
  function myFunction() {
    var x = document.getElementById("pass");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }