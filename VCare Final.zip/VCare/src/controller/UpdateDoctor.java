package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import model.Model;

public class UpdateDoctor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UpdateDoctor() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	} 

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fn= request.getParameter("firstName");
		String ln= request.getParameter("lastName");
		String email= request.getParameter("email");
		String dob= request.getParameter("dob");
		String no= request.getParameter("no");
		String height= request.getParameter("height");
		String weight= request.getParameter("weight");
		String license= request.getParameter("license");
		String speciality= request.getParameter("speciality");
		String page="";
		 
		String sql="update doctor set (first_name, last_name, email, dob, phone_no, height, weight, license,speciality)=('"+fn+"','"+ln+"','"+email+"','"+dob+"','"+no+"','"+height+"','"+weight+"', '"+license+"', '"+speciality+"') where first_name='"+fn+"'";	
		
	try{ 
		Model m = new Model();
		m.setFn(fn);
		m.setLn(ln); 
		m.setEmail(email);
		m.setDob(dob);
		m.setNo(no);
		m.setHeight(height);
		m.setWeight(weight);
		m.setLicense(license);
		m.setSpeciality(speciality);
		

		int i =Dao.common(m, sql, "update");
			if(i!=0){
				page="doctoredit.jsp?msg=success";
			}
			else{
				page="doctoredit.jsp?msg=failed";
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	response.sendRedirect(page);
	}
}
